# TermTimer
TermTimer is a terminal based timer. If you wish to contribute to our project then fork this Repository, make your edits and create a pull request. run `make install` to use `termclock` as a command

## Installation

```bash
git clone https://github.com/Kenraaliskuutteri/Termtimer
cd Termclock
make
sudo make install
